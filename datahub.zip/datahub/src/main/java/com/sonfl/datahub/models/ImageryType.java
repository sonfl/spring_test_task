package com.sonfl.datahub.models;

public enum ImageryType {
    PANCHROMATIC,
    MULTISPECTRAL,
    HYPERSPECTRAL
}
